module org.librarydatabase2 {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires mysql.connector.j;
    requires java.naming;


    opens org.librarydatabase2 to javafx.fxml;
    exports org.librarydatabase2;
}