package org.librarydatabase2;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.*;

public class BookFX extends Application {
    private user currentUser;
    private TextField searchField;
    private ListView<String> searchResults;
    private Button borrowButton;
    private Button returnButton;

    public BookFX(user user) {
        this.currentUser = user;
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Bibliotekssystem - Bokhantering");

        // Söka efter böcker
        searchField = new TextField();
        searchField.setPromptText("Sök efter böcker (Titel eller Författare)");

        Button searchButton = new Button("Sök");
        searchButton.setOnAction(e -> searchBooks());

        searchResults = new ListView<>();

        // Låna och lämna tillbaka böcker
        borrowButton = new Button("Låna vald bok");
        borrowButton.setOnAction(e -> borrowBook());

        returnButton = new Button("Lämna tillbaka vald bok");
        returnButton.setOnAction(e -> returnBook());

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.getChildren().addAll(
                new Label("Sök efter Böcker"), searchField, searchButton, searchResults,
                borrowButton, returnButton
        );

        Scene scene = new Scene(layout, 400, 500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void searchBooks() {
        String query = searchField.getText();
        searchResults.getItems().clear();

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "")) {
            String sql = "SELECT * FROM books WHERE title LIKE ? OR author LIKE ? AND available = TRUE";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, "%" + query + "%");
            statement.setString(2, "%" + query + "%");

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String book = resultSet.getInt("id") + ": " + resultSet.getString("title") + " av " + resultSet.getString("author");
                searchResults.getItems().add(book);
            }

            if (searchResults.getItems().isEmpty()) {
                showAlert(Alert.AlertType.INFORMATION, "No Results", "Inga böcker hittades.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Misslyckades med att söka efter böcker: " + e.getMessage());
        }
    }

    private void borrowBook() {
        String selectedBook = searchResults.getSelectionModel().getSelectedItem();
        if (selectedBook == null) {
            showAlert(Alert.AlertType.WARNING, "Warning", "Vänligen välj en bok att låna.");
            return;
        }

        int bookId = Integer.parseInt(selectedBook.split(":")[0]);

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "")) {
            String sql = "INSERT INTO loan (user_id,id, loan_date, return_date, status) VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 30 DAY), 'borrowed')";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, currentUser.getUserId());
            statement.setInt(2, bookId);

            int result = statement.executeUpdate();

            if (result > 0) {
                String updateBookSql = "UPDATE books SET available = FALSE WHERE id = ?";
                PreparedStatement updateBookStatement = connection.prepareStatement(updateBookSql);
                updateBookStatement.setInt(1, bookId);
                updateBookStatement.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Boken har lånats!");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Misslyckades med att låna boken.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Misslyckades med att låna boken: " + e.getMessage());
        }
    }

    private void returnBook() {
        String selectedBook = searchResults.getSelectionModel().getSelectedItem();
        if (selectedBook == null) {
            showAlert(Alert.AlertType.WARNING, "Warning", "Vänligen välj en bok att lämna tillbaka.");
            return;
        }

        int bookId = Integer.parseInt(selectedBook.split(":")[0]);

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/library", "root", "")) {
            String sql = "UPDATE loan SET status = 'returned', return_date = NOW() WHERE user_id = ? AND id = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, currentUser.getUserId());
            statement.setInt(2, bookId);

            int result = statement.executeUpdate();

            if (result > 0) {
                String updateBookSql = "UPDATE books SET available = TRUE WHERE id = ?";
                PreparedStatement updateBookStatement = connection.prepareStatement(updateBookSql);
                updateBookStatement.setInt(1, bookId);
                updateBookStatement.executeUpdate();
                showAlert(Alert.AlertType.INFORMATION, "Success", "Boken har lämnats tillbaka!");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error", "Misslyckades med att lämna tillbaka boken.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert(Alert.AlertType.ERROR, "Database Error", "Misslyckades med att lämna tillbaka boken: " + e.getMessage());
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
