package org.librarydatabase2;

import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MediaFX {
    protected int id = -1; // -1 means a "new" record
    protected String title, mediaType, author, avb = "No", rsv = "No";
    protected boolean available, reserved;
    public static TableView<MediaRow> tableView;

    public MediaFX(int id) throws SQLException {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("SELECT id, title, author, media_type, available, reserved FROM media WHERE id = ?");
        ps.setInt(1, id);
        init(ps);
    }

    public MediaFX(String search) throws SQLException {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("SELECT id, title, author, media_type, available, reserved FROM media WHERE title LIKE ? OR author LIKE ? OR media_type LIKE ?");
        String searchPattern = "%" + search + "%";
        ps.setString(1, searchPattern);
        ps.setString(2, searchPattern);
        ps.setString(3, searchPattern);
        init(ps);
    }

    public MediaFX() throws SQLException {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("SELECT id, title, author, media_type, available, reserved FROM media");
        init(ps);
    }

    private void init(PreparedStatement ps) throws SQLException {
        ObservableList<MediaRow> data = FXCollections.observableArrayList();
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            this.id = rs.getInt("id");
            this.title = rs.getString("title");
            this.author = rs.getString("author");
            this.mediaType = rs.getString("media_type");
            this.available = rs.getBoolean("available");
            this.reserved = rs.getBoolean("reserved");
            if (available) {
                avb = "Yes";
            }
            if (reserved) {
                rsv = "Yes";
            }
            data.add(new MediaRow(String.valueOf(id), title, author, mediaType, avb, rsv));
        }
        tableView = createTableView(data);
    }

    private TableView<MediaRow> createTableView(ObservableList<MediaRow> data) {
        TableView<MediaRow> table = new TableView<>();

        TableColumn<MediaRow, String> idColumn = new TableColumn<>("ID");
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));

        TableColumn<MediaRow, String> titleColumn = new TableColumn<>("Title");
        titleColumn.setCellValueFactory(new PropertyValueFactory<>("title"));

        TableColumn<MediaRow, String> authorColumn = new TableColumn<>("Author");
        authorColumn.setCellValueFactory(new PropertyValueFactory<>("author"));

        TableColumn<MediaRow, String> typeColumn = new TableColumn<>("Media Type");
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("mediaType"));

        TableColumn<MediaRow, String> availableColumn = new TableColumn<>("Available");
        availableColumn.setCellValueFactory(new PropertyValueFactory<>("available"));

        TableColumn<MediaRow, String> reservedColumn = new TableColumn<>("Reserved");
        reservedColumn.setCellValueFactory(new PropertyValueFactory<>("reserved"));

        table.getColumns().addAll(idColumn, titleColumn, authorColumn, typeColumn, availableColumn, reservedColumn);
        table.setItems(data);

        return table;
    }

    public void print() {
        System.out.printf("Contact: id=%d, title=%s, author=%s, mediaType=%s, avail=%s, reserved %s\n", id, title, author, mediaType, avb, rsv);
    }

    // Inner class to represent each row in the table
    public static class MediaRow {
        private final SimpleStringProperty id;
        private final SimpleStringProperty title;
        private final SimpleStringProperty author;
        private final SimpleStringProperty mediaType;
        private final SimpleStringProperty available;
        private final SimpleStringProperty reserved;

        public MediaRow(String id, String title, String author, String mediaType, String available, String reserved) {
            this.id = new SimpleStringProperty(id);
            this.title = new SimpleStringProperty(title);
            this.author = new SimpleStringProperty(author);
            this.mediaType = new SimpleStringProperty(mediaType);
            this.available = new SimpleStringProperty(available);
            this.reserved = new SimpleStringProperty(reserved);
        }

        public String getId() {
            return id.get();
        }

        public String getTitle() {
            return title.get();
        }

        public String getAuthor() {
            return author.get();
        }

        public String getMediaType() {
            return mediaType.get();
        }

        public String getAvailable() {
            return available.get();
        }

        public String getReserved() {
            return reserved.get();
        }
    }
}
