package org.librarydatabase2;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PersonFX {
    // Using JavaFX properties for binding
    private SimpleIntegerProperty id = new SimpleIntegerProperty(-1);
    private SimpleStringProperty firstName = new SimpleStringProperty("");
    private SimpleStringProperty lastName = new SimpleStringProperty("");
    private SimpleStringProperty nickname = new SimpleStringProperty("");

    // Constructors
    public PersonFX(int id) throws SQLException {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("SELECT id, first_name, last_name, nickname FROM person WHERE id = ?");
        ps.setInt(1, id);
        init(ps);
    }

    public PersonFX() { }

    // Initialization method to load data from ResultSet
    private void init(PreparedStatement ps) throws SQLException {
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            this.id.set(rs.getInt("id"));
            this.firstName.set(rs.getString("first_name"));
            this.lastName.set(rs.getString("last_name"));
            this.nickname.set(rs.getString("nickname"));
        }
    }

    // Getters and Setters for JavaFX properties
    public int getId() {
        return id.get();
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public String getFirstName() {
        return firstName.get();
    }

    public void setFirstName(String firstName) {
        this.firstName.set(firstName);
    }

    public String getLastName() {
        return lastName.get();
    }

    public void setLastName(String lastName) {
        this.lastName.set(lastName);
    }

    public String getNickname() {
        return nickname.get();
    }

    public void setNickname(String nickname) {
        this.nickname.set(nickname);
    }

    // JavaFX Property accessors for binding to UI components
    public SimpleIntegerProperty idProperty() {
        return id;
    }

    public SimpleStringProperty firstNameProperty() {
        return firstName;
    }

    public SimpleStringProperty lastNameProperty() {
        return lastName;
    }

    public SimpleStringProperty nicknameProperty() {
        return nickname;
    }

    // Method to print Person data
    public void print() {
        System.out.printf("Person: id=%d, first name=%s, last name=%s, nickname=%s\n", id.get(), firstName.get(), lastName.get(), nickname.get());
    }

    // Save method to handle both insert and update operations
    public int save() throws SQLException {
        String sql;

        if (getId() > 0) {
            sql = "UPDATE person SET first_name = ?, last_name = ?, nickname = ? WHERE id = ?";
        } else {
            sql = "INSERT INTO person (first_name, last_name, nickname) VALUES (?, ?, ?)";
        }

        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setString(1, getFirstName());
        ps.setString(2, getLastName());
        ps.setString(3, getNickname());

        if (getId() > 0) {
            ps.setInt(4, getId());
        }

        int numberOfChangedRows = ps.executeUpdate();

        // If the person is new, retrieve the generated ID
        if (getId() < 0) {
            ResultSet generatedKeys = ps.getGeneratedKeys();
            if (generatedKeys.next()) {
                setId(generatedKeys.getInt(1));
            }
        }

        return numberOfChangedRows;
    }

    // Delete method to remove a person from the database
    public int delete() throws SQLException {
        if (getId() < 0) {
            throw new SQLException("No person loaded!");
        }

        PreparedStatement ps = DBConnection
                .getConnection()
                .prepareStatement("DELETE FROM person WHERE id = ?");
        ps.setInt(1, getId());
        int numberOfChangedRows = ps.executeUpdate();

        if (numberOfChangedRows > 0) {
            setId(-1); // Reset ID after successful deletion
        }

        return numberOfChangedRows;
    }
}
