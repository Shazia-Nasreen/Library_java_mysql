package org.librarydatabase2;

import javafx.application.Application;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.SQLException;

public class MainFX extends Application {

    public static void main(String[] args) {
        launch(args); // Launch the JavaFX application
    }

    @Override
    public void start(Stage primaryStage) {
        // Set your database credentials
        DBConnection.username = "root";
        DBConnection.password = "";
        DBConnection.database = "Library";

        // Attempt to establish the database connection
        Connection conn = DBConnection.getConnection();
        if (conn == null) {
            System.out.println("Couldn't connect to the database.");
            System.exit(-1); // Exit if the connection fails
        } else {
            // Initialize the JavaFX Library window
            LibraryFX lib = new LibraryFX();
            lib.start(primaryStage); // Call start method of your LibraryFX class
        }
    }
}
