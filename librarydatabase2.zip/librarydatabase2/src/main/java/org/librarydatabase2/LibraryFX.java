package org.librarydatabase2;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class LibraryFX extends Application {

    private Stage window;
    private Scene initialScene, loginScene, createAccountScene, loggedScene, editScene;
    private int currentUserId = -1;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        window = primaryStage;
        window.setTitle("Library");

        // Initialize Scenes
        initInitialScene();
        initLoginScene();
        initCreateAccountScene();
        initLoggedScene();

        window.setScene(initialScene);
        window.show();
    }

    // Initial Scene - equivalent to initialPanel
    private void initInitialScene() {
        Label libTitle = new Label("Digital library");
        libTitle.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");

        Button loginBtn = new Button("Sign In");
        loginBtn.setOnAction(e -> window.setScene(loginScene));

        Button createAccountBtn = new Button("New Account");
        createAccountBtn.setOnAction(e -> window.setScene(createAccountScene));

        VBox layout = new VBox(20);
        layout.setPadding(new Insets(20));
        layout.getChildren().addAll(libTitle, loginBtn, createAccountBtn);

        initialScene = new Scene(layout, 800, 600);
    }

    // Login Scene - equivalent to loginPanel
    private void initLoginScene() {
        Label emailLabel = new Label("Email");
        TextField emailField = new TextField();
        Label passwordLabel = new Label("Password");
        PasswordField passwordField = new PasswordField();

        Button loginBtn = new Button("Log In");
        loginBtn.setOnAction(e -> {
            // Add login logic here
            window.setScene(loggedScene); // Assuming login is successful
        });

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setOnAction(e -> window.setScene(initialScene));

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.getChildren().addAll(emailLabel, emailField, passwordLabel, passwordField, loginBtn, cancelBtn);

        loginScene = new Scene(layout, 400, 300);
    }

    // Create Account Scene - equivalent to createAccount
    private void initCreateAccountScene() {
        Label nameLabel = new Label("Full Name");
        TextField nameField = new TextField();
        Label emailLabel = new Label("Email");
        TextField emailField = new TextField();
        Label passwordLabel = new Label("Password");
        PasswordField passwordField = new PasswordField();
        Label repeatPassLabel = new Label("Repeat Password");
        PasswordField repeatPasswordField = new PasswordField();

        Button createBtn = new Button("Create");
        createBtn.setOnAction(e -> {
            // Add create account logic here
            window.setScene(initialScene); // Assuming account creation is successful
        });

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setOnAction(e -> window.setScene(initialScene));

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.getChildren().addAll(nameLabel, nameField, emailLabel, emailField, passwordLabel, passwordField, repeatPassLabel, repeatPasswordField, createBtn, cancelBtn);

        createAccountScene = new Scene(layout, 400, 400);
    }

    // Logged-in Scene - equivalent to loggedPanel
    private void initLoggedScene() {
        Label welcomeLabel = new Label("Welcome, User!"); // Change to the actual user name dynamically

        Button loanHistoryBtn = new Button("Loan History");
        loanHistoryBtn.setOnAction(e -> {
            // Add loan history logic here
        });

        Button currentLoanBtn = new Button("Current Loan");
        currentLoanBtn.setOnAction(e -> {
            // Add current loan logic here
        });

        Button editProfileBtn = new Button("Edit Profile");
        editProfileBtn.setOnAction(e -> {
            // Implement edit profile scene
            window.setScene(editScene);
        });

        Button logoutBtn = new Button("Log Out");
        logoutBtn.setOnAction(e -> window.setScene(initialScene));

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.getChildren().addAll(welcomeLabel, loanHistoryBtn, currentLoanBtn, editProfileBtn, logoutBtn);

        loggedScene = new Scene(layout, 400, 300);
    }

    // Edit Profile Scene - equivalent to editPanel
    private void initEditProfileScene() {
        Label nameLabel = new Label("Full Name");
        TextField nameField = new TextField(); // setText with the actual name
        Label emailLabel = new Label("Email");
        TextField emailField = new TextField(); // setText with the actual email

        Button saveBtn = new Button("Save");
        saveBtn.setOnAction(e -> {
            // Add save logic here
            window.setScene(loggedScene); // Go back to logged in scene
        });

        Button cancelBtn = new Button("Cancel");
        cancelBtn.setOnAction(e -> window.setScene(loggedScene));

        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));
        layout.getChildren().addAll(nameLabel, nameField, emailLabel, emailField, saveBtn, cancelBtn);

        editScene = new Scene(layout, 400, 300);
    }
}
