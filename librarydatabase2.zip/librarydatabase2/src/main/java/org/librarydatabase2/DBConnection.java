package org.librarydatabase2;

import com.mysql.cj.jdbc.MysqlDataSource;
import javafx.scene.control.Alert;

import java.sql.Connection;
import java.sql.SQLException;

public class DBConnection {

    public static String url = "localhost";
    static int port = 3306;
    public static String username = "root";
    public static String password = "";
    public static String database = "library";

    private static DBConnection dbInstance;

    private MysqlDataSource dataSource;

    // Private constructor to enforce singleton pattern
    private DBConnection() {
        initDataSource();
    }

    // Initialize the MySQL DataSource with connection properties
    private void initDataSource() {
        try {
            dataSource = new MysqlDataSource();
            dataSource.setUser(username);
            dataSource.setPassword(password);
            dataSource.setURL("jdbc:mysql://" + url + ":" + port + "/" + database + "?serverTimezone=UTC");
        } catch (Exception e) {
            e.printStackTrace();
            showDatabaseError("Failed to initialize data source", e.getMessage());
        }
    }

    // Create a new connection
    private Connection createConnection() {
        try {
            return dataSource.getConnection();
        } catch (SQLException e) {
            SQLExceptionPrint(e);
            showDatabaseError("Database Connection Error", e.getMessage());
            return null;
        }
    }

    // Get a connection from the singleton instance
    public static Connection getConnection() {
        if (dbInstance == null) {
            dbInstance = new DBConnection();
        }
        return dbInstance.createConnection();
    }

    // Print SQLException details
    public static void SQLExceptionPrint(SQLException sqlException, boolean printStackTrace) {
        while (sqlException != null) {
            System.out.println("\n--SQLException Caught---\n");
            System.out.println("SQL state: " + sqlException.getSQLState());
            System.out.println("Error code: " + sqlException.getErrorCode());
            System.out.println("Message: " + sqlException.getMessage());
            if (printStackTrace) sqlException.printStackTrace();
            sqlException = sqlException.getNextException();
        }
    }

    // Overloaded method for printing SQL exceptions without stack trace
    public static void SQLExceptionPrint(SQLException sqlException) {
        SQLExceptionPrint(sqlException, false);
    }

    // Display error messages using JavaFX Alert
    private void showDatabaseError(String title, String message) {
        javafx.application.Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(title);
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }
}
