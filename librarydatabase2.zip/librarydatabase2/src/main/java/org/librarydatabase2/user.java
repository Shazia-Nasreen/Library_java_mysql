package org.librarydatabase2;

public class user {
    public void setName(String text) {
    }

    public void setEmail(String text) {
    }

    public void setPassword(String text) {
    }

    public int save() {
        return 0;
    }





    public String getName() {
        return "";
    }

    public void setFullName(String text) {
    }

    public String getFullName() {
        return "";
    }

    public String getEmail() {
        return "";
    }

    public String getPassword() {
        return "";
    }

    public int getUserId() {
        return 0;
    }

    public void setUserId(int anInt) {
    }
}
